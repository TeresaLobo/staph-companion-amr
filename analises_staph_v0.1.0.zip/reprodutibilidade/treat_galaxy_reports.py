from pathlib import Path
import zipfile, re, io, json
import pandas as pd
p=Path(__file__).resolve().parents[1]
dest=p/'reanotacao_sem_wsl/relatorios_tratados';dest.mkdir(exist_ok=True)
m=pd.read_csv(p/'dados/genomas_metadados_resultados.csv').set_index('genome_id')
frames=[];seen=set();checks=[]
with zipfile.ZipFile(p/'reanotacao_sem_wsl/amrfinder_415_Galaxy.zip') as z:
    assert z.testzip() is None
    for n in z.namelist():
        gid=re.search(r'(GCF_\d+\.\d+_.+)\.fna\.tabular$',n).group(1)
        assert gid in m.index and gid not in seen;seen.add(gid)
        df=pd.read_csv(io.BytesIO(z.read(n)),sep='\t')
        assert {'Element symbol','Type','Database version','Tool version','Contig id','Start','Stop'}<=set(df.columns)
        assert df['Database version'].eq('2026-05-15.1').all() and df['Tool version'].astype(str).eq('4.2.7').all()
        checks.append({'genome_id':gid,'report_readable':True,'hits':len(df)})
        df.insert(0,'genome_id',gid);df.insert(1,'species',m.loc[gid,'species']);frames.append(df)
assert seen==set(m.index) and len(seen)==415
hits=pd.concat(frames,ignore_index=True)
hits.to_csv(dest/'amrfinder_combinado_415.csv',index=False)
pd.DataFrame(checks).to_csv(dest/'integridade_relatorios_415.csv',index=False)
genes=['mecA','mecC','fexA','fexB','cfr','cfr(B)','cfr(C)','cfr(D)','optrA','poxtA','mecA1']
summary=m[['species','host_grupo','biosample','bioproject']].copy()
for gene in genes:summary[gene]=hits[hits['Element symbol'].eq(gene)].groupby('genome_id').size().reindex(m.index,fill_value=0)
summary.to_csv(dest/'alvos_por_genoma_415.csv')
summary.groupby('species')[genes].agg(lambda x:int(x.gt(0).sum())).to_csv(dest/'alvos_por_especie_415.csv')
summary.groupby('host_grupo')[genes].agg(lambda x:int(x.gt(0).sum())).to_csv(dest/'alvos_por_hospedeiro_415.csv')
old=pd.read_csv(p/'dados/amrfinder_reconstruido_individuais.csv')
a=old.groupby(['genome_id','Element symbol','Type']).size().rename('archived_hits')
b=hits.groupby(['genome_id','Element symbol','Type']).size().rename('new_hits')
c=pd.concat([a,b],axis=1).fillna(0).astype(int).reset_index();c['difference']=c.new_hits-c.archived_hits
c.to_csv(dest/'comparacao_arquivado_novo.csv',index=False)
result={'reports':415,'CRC_and_headers':'passed','annotation_translation_validation_complete':False,'database':'2026-05-15.1','tool':'4.2.7','type_counts':hits.Type.value_counts().to_dict(),'positive_genomes_per_target':{g:int(summary[g].gt(0).sum()) for g in genes},'companion_animals':int(summary.host_grupo.isin(['cao','gato']).sum()),'manuscript_uses_archived_414':True}
(dest/'resumo_tratamento.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
