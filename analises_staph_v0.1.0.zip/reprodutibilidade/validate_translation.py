from pathlib import Path
import pandas as pd,json,itertools,sys
ROOT=Path(__file__).resolve().parents[1]
SRC=Path(sys.argv[1]) if len(sys.argv)>1 else Path(r'D:\BACKUP_WSL_2026\01_PROJETOS\staph_optra_mobilome')
OUT=Path(sys.argv[2]) if len(sys.argv)>2 else ROOT
sys.path.insert(0,str(ROOT/'work'))
# Keep FASTA/GFF parsers local to avoid running the reconstruction on import.
def fasta(path):
    out={};ident=None;seq=[]
    for line in path.read_bytes().splitlines():
        if line.startswith(b'>'):
            if ident:out[ident]=b''.join(seq).decode('ascii',errors='replace').upper()
            ident=line[1:].split()[0].decode();seq=[]
        else:seq.append(line.strip())
    if ident:out[ident]=b''.join(seq).decode('ascii',errors='replace').upper()
    return out
def cds(path):
    out={}
    for line in path.open(encoding='utf-8',errors='replace'):
        if line.startswith('##FASTA'):break
        if line.startswith('#'):continue
        a=line.rstrip().split('\t')
        if len(a)!=9 or a[2]!='CDS':continue
        attr=dict(x.split('=',1) for x in a[8].split(';') if '=' in x)
        out[attr['ID']]=(a[0],int(a[3]),int(a[4]),a[6],int(a[7]))
    return out
bases='TCAG';aas='FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG'
table=dict(zip((''.join(x) for x in itertools.product(bases,repeat=3)),aas))
iupac={'A':'A','C':'C','G':'G','T':'T','R':'AG','Y':'CT','S':'GC','W':'AT','K':'GT','M':'AC','B':'CGT','D':'AGT','H':'ACT','V':'ACG','N':'ACGT'}
complement=str.maketrans('ACGTRYSWKMBDHVN','TGCAYRSWMKVHDBN')
starts={'TTG','CTG','ATT','ATC','ATA','ATG','GTG'}
def translate(seq,strand,phase):
    if strand=='-':seq=seq.translate(complement)[::-1]
    seq=seq[phase:]
    aa=[]
    for i in range(0,len(seq)-2,3):
        cod=seq[i:i+3]
        if cod in table:v=table[cod]
        else:
            options={table[''.join(x)] for x in itertools.product(*(iupac[c] for c in cod))}
            v=next(iter(options)) if len(options)==1 else 'X'
        aa.append('M' if i==0 and cod in starts else v)
    return ''.join(aa).rstrip('*')
master=pd.read_csv(SRC/'metadata/genome_master_table.tsv',sep='\t').set_index('genome_id')
context=pd.read_csv(OUT/'dados/contexto_genetico_alvos.csv')
checks=[]
for gid,sub in context.groupby('genome_id'):
    dna=fasta(SRC/master.loc[gid,'genome_file'].split('/staph_optra_mobilome/')[1]);ann=SRC/'results/prokka'/gid
    features=cds(ann/(gid+'.gff'));proteins=fasta(ann/(gid+'.faa'))
    for r in sub.itertuples():
        contig,start,end,strand,phase=features[r.protein_id]
        translated=translate(dna[contig][start-1:end],strand,phase)
        protein=proteins[r.protein_id].rstrip('*')
        # Prodigal permits partial genes with a non-M initial residue.
        identical=translated==protein or (translated[1:]==protein[1:] and translated[:1]=='M')
        checks.append(dict(genome_id=gid,gene=r.gene,protein_id=r.protein_id,translated_length=len(translated),protein_length=len(protein),translation_matches=identical))
checks=pd.DataFrame(checks);checks.to_csv(OUT/'validacao/traducao_CDS_alvos.csv',index=False)
assert checks.translation_matches.all(),checks[~checks.translation_matches].to_string()
print(json.dumps({'target_CDS_translations_checked':len(checks),'all_match':bool(checks.translation_matches.all())},indent=2))

