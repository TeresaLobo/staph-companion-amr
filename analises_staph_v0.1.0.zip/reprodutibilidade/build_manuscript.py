from pathlib import Path
import pandas as pd, re, html, json, subprocess
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether
from reportlab.graphics.shapes import Drawing, Rect, String, Line, Polygon
from reportlab.graphics import renderPDF, renderSVG

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT;FIG=OUT/'figuras'
POP=Path(r'C:\Users\teca_\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe')
for name,file in [('TimesResearch','times.ttf'),('TimesResearch-Bold','timesbd.ttf'),('TimesResearch-Italic','timesi.ttf'),('TimesResearch-BoldItalic','timesbi.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(Path(r'C:\Windows\Fonts')/file)))
pdfmetrics.registerFontFamily('TimesResearch',normal='TimesResearch',bold='TimesResearch-Bold',italic='TimesResearch-Italic',boldItalic='TimesResearch-BoldItalic')
species=pd.read_csv(OUT/'tabelas/Tabela1_especies.csv');hosts=pd.read_csv(OUT/'tabelas/Tabela2_hospedeiros.csv')
context=pd.read_csv(OUT/'tabelas/Tabela3_contexto_cfr_fexA.csv');nei=pd.read_csv(OUT/'dados/vizinhanca_cfr_fexA_10kb.csv')
def short(sp):return sp.replace('Staphylococcus ','S. ').replace('Mammaliicoccus ','M. ')
def drawtext(d,x,y,s,size=10,anchor='start',font='TimesResearch'):
    d.add(String(x,y,str(s),fontName=font,fontSize=size,textAnchor=anchor,fillColor=colors.black))
def savefigure(d,name):
    renderPDF.drawToFile(d,str(FIG/(name+'.pdf')));renderSVG.drawToFile(d,str(FIG/(name+'.svg')))
    subprocess.run([str(POP),'-r','300','-png','-singlefile',str(FIG/(name+'.pdf')),str(FIG/name)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    # Publication raster with real DPI metadata.
    from PIL import Image as PILImage
    image=PILImage.open(FIG/(name+'.png'));image.save(FIG/(name+'.tiff'),compression='tiff_lzw',dpi=(300,300))

d=Drawing(450,520);drawtext(d,12,495,'Genes-alvo por espécie',16,font='TimesResearch-Bold')
drawtext(d,12,476,'Genomas positivos / genomas analisados',10)
cols=['mecA','mecA1','fexA','cfr']
for j,g in enumerate(cols):drawtext(d,241+j*51,447,g,11,anchor='middle',font='TimesResearch-Italic')
for i,r in species.iterrows():
    y=419-i*23;drawtext(d,8,y+7,short(r.species),10,font='TimesResearch-Italic')
    for j,g in enumerate(cols):
        v=int(r[g])/int(r.n_analisados); gray=1-v*.7
        d.add(Rect(216+j*51,y,49,22,fillColor=colors.Color(gray,gray,gray),strokeColor=colors.white))
        d.add(String(241+j*51,y+7,f'{int(r[g])}/{int(r.n_analisados)}',fontName='TimesResearch',fontSize=10,textAnchor='middle',fillColor=colors.white if v>.7 else colors.black))
drawtext(d,8,26,'mecA1 é apresentado separadamente dos alvos exatos',9)
drawtext(d,8,12,'As frequências descrevem a coleção selecionada',9)
savefigure(d,'Figura1_genes_por_especie')

# Comparative local gene neighborhoods. Gray is sequence context, black target.
d=Drawing(450,560);drawtext(d,10,535,'Contexto local de cfr e fexA',16,font='TimesResearch-Bold')
drawtext(d,10,517,'Coordenadas relativas ao início do gene-alvo',10)
rows=context.sort_values(['gene','species','genome_id'])
plotleft=28;plotright=423;scale=(plotright-plotleft)/20000
for i,r in enumerate(rows.itertuples()):
    y=466-i*61
    label=f'{r.gene}  |  {short(r.species)}  |  '+r.genome_id.split('_ASM')[0].split('_Sta')[0]
    drawtext(d,10,y+20,label,9)
    left=max(-10000,1-r.start);right=min(10000,r.contig_length-r.start)
    xx=lambda v:plotleft+(v+10000)*scale
    d.add(Line(xx(left),y,xx(right),y,strokeColor=colors.black,strokeWidth=.5))
    feats=nei[(nei.genome_id==r.genome_id)&(nei.target_gene==r.gene)]
    for f in feats.itertuples():
        a=max(left,f.start-r.start);b=min(right,f.end-r.start)
        if a>=b:continue
        x1,x2=xx(a),xx(b);h=5;tip=min(4,(x2-x1)/2)
        target=f.id==r.protein_id
        if f.strand=='+':points=[x1,y-h,x2-tip,y-h,x2,y,x2-tip,y+h,x1,y+h]
        else:points=[x2,y-h,x1+tip,y-h,x1,y,x1+tip,y+h,x2,y+h]
        d.add(Polygon(points,fillColor=colors.black if target else colors.Color(.8,.8,.8),strokeColor=colors.black,strokeWidth=.35))
        if target:drawtext(d,(x1+x2)/2,y+8,r.gene,8,anchor='middle',font='TimesResearch-Italic')
    drawtext(d,plotright,y-17,f'contig: {r.contig_length:,} pb'.replace(',','.'),8,anchor='end')
for v in [-10000,-5000,0,5000,10000]:
    x=plotleft+(v+10000)*scale;d.add(Line(x,37,x,41,strokeColor=colors.black));drawtext(d,x,24,f'{v//1000} kb',8,anchor='middle')
drawtext(d,10,8,'Seta preta: alvo; cinza: demais CDS; contexto não demonstra transferência',8)
savefigure(d,'Figura2_contexto_genetico')

styles={
 'body':ParagraphStyle('Body',fontName='TimesResearch',fontSize=12,leading=24,alignment=4,spaceAfter=8),
 'title':ParagraphStyle('Title',fontName='TimesResearch-Bold',fontSize=15,leading=20,alignment=1,spaceAfter=12),
 'english':ParagraphStyle('English',fontName='TimesResearch-Italic',fontSize=12,leading=17,alignment=1,spaceAfter=12),
 'author':ParagraphStyle('Author',fontName='TimesResearch',fontSize=12,leading=16,alignment=1,spaceAfter=10),
 'heading':ParagraphStyle('Heading',fontName='TimesResearch-Bold',fontSize=12,leading=18,spaceBefore=15,spaceAfter=9,keepWithNext=True),
 'caption':ParagraphStyle('Caption',fontName='TimesResearch',fontSize=10,leading=13,spaceBefore=6,spaceAfter=8),
 'cell':ParagraphStyle('Cell',fontName='TimesResearch',fontSize=9,leading=11,spaceAfter=0),
 'ref':ParagraphStyle('Ref',fontName='TimesResearch',fontSize=10,leading=13,alignment=4,spaceAfter=6)}
def markup(s):
    s=html.escape(s)
    s=re.sub(r'\*([^*]+)\*',r'<i>\1</i>',s)
    s=re.sub(r'\b(mecA1|mecA|mecC|mecI|mecR1|fexA|fexB|cfr|optrA|poxtA|fosB|blaI|blaR1)\b',r'<i>\1</i>',s)
    s=re.sub(r'(Staphylococcus\s+(?:pseudintermedius|capitis|coagulans|felis|sciuri|aureus|haemolyticus)|Mammaliicoccus sciuri|S\.\s+(?:pseudintermedius|capitis|coagulans|felis|schleiferi|aureus|haemolyticus|chromogenes|hyicus|simulans)|M\. sciuri)',r'<i>\1</i>',s)
    return s
def table(data,widths):
    rows=[[Paragraph(markup(str(c)),styles['cell']) for c in row] for row in data]
    t=Table(rows,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('LINEABOVE',(0,0),(-1,0),.7,colors.black),('LINEBELOW',(0,0),(-1,0),.5,colors.black),('LINEBELOW',(0,-1),(-1,-1),.7,colors.black),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]))
    return t
width=A4[0]-6*cm
t1=[['Espécie','n','mecA','mecA1','fexA','cfr']]+[[short(r.species),str(r.n_analisados),str(r.mecA),str(r.mecA1),str(r.fexA),str(r.cfr)] for r in species.itertuples()]
hostlabels={'bovino':'Bovino','camelideo':'Camelídeo','cao':'Cão','gato':'Gato','humano':'Humano','nao_informado':'Não informado','outro_animal':'Outro animal','ovino':'Ovino','suino':'Suíno','vegetal':'Vegetal'}
t2=[['Hospedeiro','n','Qualquer AMR','mecA','fexA','cfr']]+[[hostlabels[r.host_grupo],str(r.n_analisados),str(r.qualquer_AMR),str(r.mecA),str(r.fexA),str(r.cfr)] for r in hosts.itertuples()]
t3=[['Acesso','Gene','Origem','Contig pb','Identidade %']]+[[r.genome_id.split('_')[0]+'_'+r.genome_id.split('_')[1].split('_')[0].split('_ASM')[0].split('_Sta')[0].split('_Z')[0],r.gene,hostlabels[r.host_grupo],str(r.contig_length),f'{r.identity:.2f}'.replace('.',',')] for r in rows.itertuples()]
# Assembly accession is the first complete GCF/GCA token.
for row,r in zip(t3[1:],rows.itertuples()):row[0]=re.match(r'GC[AF]_\d+\.\d+',r.genome_id).group(0)
tables={'Tabela 1':(t1,[width*.47]+[width*.106]*5,'Tabela 1. Número de genomas analisados e detecções por espécie'),
 'Tabela 2':(t2,[width*.3,width*.1,width*.23,width*.13,width*.12,width*.12],'Tabela 2. Elementos AMR e alvos segundo o hospedeiro informado'),
 'Tabela 3':(t3,[width*.29,width*.10,width*.23,width*.19,width*.19],'Tabela 3. Detecções de cfr e fexA e características do contig')}
text=(OUT/'manuscrito/manuscrito_portugues.md').read_text(encoding='utf-8-sig')
blocks=re.split(r'\n\s*\n',text.strip());story=[];inserted=set();section=''
rtf=[r'{\rtf1\ansi\deff0{\fonttbl{\f0 Times New Roman;}}\paperw11906\paperh16838\margl1701\margr1701\margt1701\margb1701\linemod1\linex240\f0\fs24 ']
def rt(s):
    out=[]
    for c in s:
        n=ord(c)
        if c in '{}\\':out.append('\\'+c)
        elif n<128:out.append(c)
        else:out.append('\\u'+str(n if n<32768 else n-65536)+'?')
    return ''.join(out)
def rtfpara(s,bold=False,center=False,italic=False,ref=False):
    s=s.replace('*','')
    return '\\pard'+('\\qc' if center else '\\qj')+('\\sl240\\slmult1' if ref else '\\sl480\\slmult1')+'\\sa120'+('\\b' if bold else '')+('\\i' if italic else '')+' '+rt(s)+'\\b0\\i0\\par\n'
def rtftable(data,widths):
    out=[]
    for row in data:
        out.append('\\trowd\\trgaph90\\trleft0')
        pos=0
        for w in widths:pos+=int(w*20);out.append('\\cellx'+str(pos))
        for v in row:out.append('\\pard\\intbl\\fs20\\sl240 '+rt(str(v))+'\\cell ')
        out.append('\\row\n')
    out.append('\\pard\\fs24\n');return ''.join(out)
def rtffig(path,w,h):
    from PIL import Image as PI
    im=PI.open(path)
    return '{\\pict\\pngblip\\picw'+str(im.width)+'\\pich'+str(im.height)+'\\picwgoal'+str(int(w*20))+'\\pichgoal'+str(int(h*20))+'\n'+path.read_bytes().hex()+'}\n\\par\n'
for block in blocks:
    if block.startswith('# '):
        label=block[2:];story.append(Paragraph(markup(label),styles['title']));rtf.append(rtfpara(label,True,True));continue
    if block.startswith('## '):
        section=block[3:];story.append(Paragraph(section.upper(),styles['heading']));rtf.append(rtfpara(section.upper(),True));continue
    style=styles['ref'] if section=='Referências' else styles['body']
    if block.startswith('*Resistance'):
        style=styles['english'];rtf.append(rtfpara(block,center=True,italic=True))
    elif block.startswith('Teresa de Lisieux'):
        style=styles['author'];rtf.append(rtfpara(block,center=True))
    else:rtf.append(rtfpara(block,ref=section=='Referências'))
    story.append(Paragraph(markup(block),style))
    for key,(data,widths,caption) in tables.items():
        if key in block and key not in inserted:
            story.extend([Spacer(1,7),Paragraph(caption,styles['caption']),table(data,widths),Spacer(1,10)])
            rtf.extend([rtfpara(caption),rtftable(data,widths)]);inserted.add(key)
    if 'Figura 1' in block and 'fig1' not in inserted:
        w=width;h=w*520/450;path=FIG/'Figura1_genes_por_especie.png'
        caption='Figura 1. Detecções por símbolo exato e por espécie com mecA1 separado; numeradores representam genomas positivos e denominadores representam genomas analisados'
        story.extend([Image(str(path),width=w,height=h),Paragraph(caption,styles['caption'])]);rtf.extend([rtffig(path,w,h),rtfpara(caption)]);inserted.add('fig1')
# Genetic context is discussed in Table 3; attach the figure beside its final mention.
story.extend([PageBreak(),Paragraph('FIGURA SUPLEMENTAR',styles['heading']),Image(str(FIG/'Figura2_contexto_genetico.png'),width=width,height=width*560/450),Paragraph('Figura S1. Vizinhança de cfr e fexA com até 10 kb de cada lado limitada pelo contig. Setas indicam orientação das sequências codificadoras; as setas pretas destacam o alvo. Escala relativa comum. A vizinhança não estabelece mobilidade ou transferência horizontal',styles['caption'])])
rtf.extend(['\\page\n',rtfpara('FIGURA SUPLEMENTAR',True),rtffig(FIG/'Figura2_contexto_genetico.png',width,width*560/450),rtfpara('Figura S1. Vizinhança de cfr e fexA; setas pretas destacam o alvo e setas cinzas indicam demais sequências codificadoras. Escala comum. Não demonstra transferência horizontal.'),'}'])
(OUT/'manuscrito/manuscrito_portugues.rtf').write_text(''.join(rtf),encoding='ascii')
def page(canvas,doc):
    canvas.setFont('TimesResearch',10);canvas.drawRightString(A4[0]-3*cm,2*cm,str(doc.page))
doc=SimpleDocTemplate(str(OUT/'manuscrito/manuscrito_portugues.pdf'),pagesize=A4,rightMargin=3*cm,leftMargin=3*cm,topMargin=3*cm,bottomMargin=3*cm,title='Determinantes de resistência em genomas de Staphylococcaceae',author='Teresa de Lisieux Guedes Ferreira Lôbo')
doc.build(story,onFirstPage=page,onLaterPages=page)
print('PDF e RTF gerados; figuras PDF SVG PNG TIFF geradas',flush=True)
