from pathlib import Path
import pandas as pd,sys
SRC=Path(sys.argv[1]) if len(sys.argv)>1 else Path(r'D:\BACKUP_WSL_2026\01_PROJETOS\staph_optra_mobilome')
OUT=Path(sys.argv[2]) if len(sys.argv)>2 else Path(__file__).resolve().parents[1]
master=pd.read_csv(SRC/'metadata/genome_master_table.tsv',sep='\t');rows=[]
for r in master.itertuples():
    ann=SRC/'results/prokka'/r.genome_id
    proteins=set(line[1:].split()[0].decode() for line in (ann/(r.genome_id+'.faa')).read_bytes().splitlines() if line.startswith(b'>'))
    cds=set();has_fasta=False;truncated_attribute=0
    with (ann/(r.genome_id+'.gff')).open(encoding='utf-8',errors='replace') as f:
        for line in f:
            if line.startswith('##FASTA'):has_fasta=True;break
            if line.startswith('#'):continue
            a=line.rstrip().split('\t')
            if len(a)==9 and a[2]=='CDS':
                attrs=dict(x.split('=',1) for x in a[8].split(';') if '=' in x)
                cds.add(attrs.get('ID',''))
    rows.append(dict(genome_id=r.genome_id,n_protein_ids=len(proteins),n_CDS_ids=len(cds),proteins_without_CDS=len(proteins-cds),CDS_without_protein=len(cds-proteins),gff_embedded_fasta_present=has_fasta))
data=pd.DataFrame(rows);data.to_csv(OUT/'validacao/completude_anotacoes.csv',index=False)
print(data[(data.proteins_without_CDS>0)|(data.CDS_without_protein>0)|(~data.gff_embedded_fasta_present)].to_string(index=False))
