from pathlib import Path
import pandas as pd, numpy as np, re, json, hashlib, sys
from urllib.parse import unquote
from collections import Counter

ROOT=Path(__file__).resolve().parents[1]
SRC=Path(sys.argv[1]) if len(sys.argv)>1 else Path(r'D:\BACKUP_WSL_2026\01_PROJETOS\staph_optra_mobilome')
OUT=Path(sys.argv[2]) if len(sys.argv)>2 else ROOT
for d in ['dados','tabelas','figuras','validacao','reprodutibilidade','manuscrito']: (OUT/d).mkdir(parents=True,exist_ok=True)
def read(p):return pd.read_csv(p,sep='\t',dtype=str,keep_default_na=False)
def csv(df,name,folder='dados'):df.to_csv(OUT/folder/name,index=False,encoding='utf-8-sig')
def fasta(path):
    records={}; ident=None; buf=[]; errors=[]
    with path.open('rb') as f:
        for raw in f:
            if raw.startswith(b'>'):
                if ident is not None:
                    if ident in records: errors.append('duplicate_id:'+ident)
                    records[ident]=b''.join(buf).upper()
                ident=raw[1:].split()[0].decode('ascii',errors='replace');buf=[]
            else:
                seq=raw.strip()
                if seq and ident is None:errors.append('sequence_without_header')
                buf.append(seq)
    if ident is not None:
        if ident in records:errors.append('duplicate_id:'+ident)
        records[ident]=b''.join(buf).upper()
    return records,errors
def gff(path):
    cds=[];errs=[]
    with path.open(encoding='utf-8',errors='replace') as f:
        for line in f:
            if line.startswith('##FASTA'):break
            if line.startswith('#') or not line.strip():continue
            cols=line.rstrip('\n').split('\t')
            if len(cols)!=9:errs.append('malformed_gff');continue
            if cols[2]!='CDS':continue
            attr={k:unquote(v) for k,v in (p.split('=',1) for p in cols[8].split(';') if '=' in p)}
            cds.append(dict(contig=cols[0],start=int(cols[3]),end=int(cols[4]),strand=cols[6],id=attr.get('ID',''),locus_tag=attr.get('locus_tag',''),gene=attr.get('gene',''),product=attr.get('product','')))
    return cds,errs
def hostmap(value):
    h=str(value).strip().casefold()
    groups={
        'cao':{'canis lupus familiaris','canis familiaris','dog','canine'},
        'gato':{'felis catus','felis silvestris catus','cat','cats','feline'},
        'humano':{'homo sapiens','human'},
        'bovino':{'bos taurus','bovine','cow','lactating dairy cow','bos taurus (dairy cow)','bos taurus (cow)'},
        'suino':{'sus scrofa','susscrofa domestica','swine','pig'},
        'ovino':{'sheep'},'camelideo':{'camel'},
        'outro_animal':{'halichoerus grypus (grey seal)','mirounga leonina','arctocephalus gazella','rhipicephalus microplus','mouse','stegodyphus dumicola','sciurus carolinensis','animal'},
        'vegetal':{'oryza sativa','rice'},
        'nao_informado':{'','nan','missing','not applicable','not provided','not collected','unknown'}}
    return next((g for g,s in groups.items() if h in s),'revisar')

master=read(SRC/'metadata/genome_master_table.tsv')
meta=pd.read_csv(Path(sys.argv[3]) if len(sys.argv)>3 else Path(__file__).with_name('metadados_NCBI_recuperados.csv'),keep_default_na=False)
meta['host_grupo']=meta.host_original.map(hostmap)
meta['species_original']=meta.species
meta['species']=meta.species.replace({'Staphylococcus sciuri':'Mammaliicoccus sciuri'})
statuses=read(SRC/'metadata/amrfinder_faa_only_run_index.tsv').set_index('genome_id').status.to_dict()
consolidated=read(SRC/'results/amrfinder_faa_only/AMRFINDER_FAA_ONLY_ALL_RESULTS.tsv')
quality=[];frames=[];contexts=[];neighborhood=[];assemblies={};exclusions=[]
targetlist=['mecA','mecC','fexA','fexB','cfr','cfr(B)','cfr(C)','cfr(D)','optrA','poxtA']
for i,r in master.iterrows():
    gid=r.genome_id
    fna=SRC/r.genome_file.split('/staph_optra_mobilome/')[1]
    ann=SRC/'results/prokka'/gid
    dna,derr=fasta(fna); proteins,perr=fasta(ann/(gid+'.faa'));cds,gerr=gff(ann/(gid+'.gff'))
    dchars=set(b''.join(dna.values()))-set(b'ACGTRYSWKMBDHVN')
    pchars=set(b''.join(proteins.values()))-set(b'ACDEFGHIKLMNPQRSTVWYBXZJUO*')
    pempty=sum(not x for x in proteins.values()); internal=sum(b'*' in x.rstrip(b'*') for x in proteins.values())
    dsize=sum(map(len,dna.values()));lengths=sorted(map(len,dna.values()),reverse=True);cumul=0;n50=0
    for le in lengths:
        cumul+=le
        if cumul>=dsize/2:n50=le;break
    seq_hash=hashlib.sha256(b'|'.join(sorted(dna.values()))).hexdigest()
    assemblies.setdefault(seq_hash,[]).append(gid)
    cdsmap={x['id']:x for x in cds}
    gffbounds=sum(x['contig'] not in dna or x['start']<1 or x['end']>len(dna.get(x['contig'],b'')) or x['end']<x['start'] for x in cds)
    result_path=SRC/'results/amrfinder_faa_only'/(gid+'.amrfinder.tsv')
    hits=read(result_path) if result_path.exists() else pd.DataFrame(columns=[c for c in consolidated.columns if c not in ['genome_id','species']])
    missingprotein=sum(x not in proteins for x in hits['Protein id'])
    lengthmismatch=sum(int(x['Target length'])!=len(proteins.get(x['Protein id'],b'').rstrip(b'*')) for x in hits.to_dict('records'))
    rawok=not (derr or dchars or not dna)
    proteinok=not (perr or pchars or pempty or internal)
    eligible=statuses[gid]=='success' and rawok and proteinok and not(gerr or gffbounds or missingprotein or lengthmismatch)
    q=dict(genome_id=gid,species=meta.loc[meta.genome_id.eq(gid),'species'].iloc[0],run_status=statuses[gid],eligible=eligible,n_contigs=len(dna),length=dsize,N50=n50,ambiguous_bases=sum(len(seq)-sum(seq.count(c) for c in [b'A',b'C',b'G',b'T']) for seq in dna.values()),dna_invalid_codes=','.join(map(str,sorted(dchars))),protein_invalid_codes=','.join(map(str,sorted(pchars))),fasta_errors=';'.join(derr+perr),internal_stops=internal,empty_proteins=pempty,gff_errors=len(gerr),gff_invalid_coordinates=gffbounds,missing_hit_proteins=missingprotein,hit_protein_length_mismatches=lengthmismatch,assembly_sequence_sha256=seq_hash)
    quality.append(q)
    if not eligible:exclusions.append(q)
    if statuses[gid]=='success':
        hits.insert(0,'species',r.species);hits.insert(0,'genome_id',gid);frames.append(hits)
    if eligible:
        for hit in hits.loc[hits['Element symbol'].isin(targetlist+['mecA1'])].to_dict('records'):
            feature=cdsmap.get(hit['Protein id'])
            if not feature:raise ValueError('Unmapped target CDS '+gid+' '+hit['Protein id'])
            seq=dna[feature['contig']]
            same=[x for x in cds if x['contig']==feature['contig']]
            win=[x for x in same if x['start']<=feature['end']+10000 and x['end']>=feature['start']-10000]
            mobility=[x for x in win if re.search(r'transpos|integrase|recombinase|insertion sequence|resolvase',x['product']+' '+x['gene'],re.I)]
            contig_hint=feature['contig'].lower()
            contexts.append(dict(genome_id=gid,species=q['species'],gene=hit['Element symbol'],protein_id=hit['Protein id'],contig=feature['contig'],start=feature['start'],end=feature['end'],strand=feature['strand'],contig_length=len(seq),distance_left=feature['start']-1,distance_right=len(seq)-feature['end'],n_CDS_window=len(win),n_mobility_annotations_window=len(mobility),mobility_annotations=';'.join(x['product'] for x in mobility),plasmid_name_hint='plasmid' in contig_hint,method=hit['Method'],coverage=hit['% Coverage of reference'],identity=hit['% Identity to reference']))
            if hit['Element symbol'] in ['fexA','cfr']:
                for feat in win:neighborhood.append(dict(genome_id=gid,target_gene=hit['Element symbol'],target_protein=hit['Protein id'],**feat))
    if (i+1)%50==0:print(f'Validados {i+1}/415',flush=True)

quality=pd.DataFrame(quality);csv(quality,'controle_integridade.csv','validacao')
rebuilt=pd.concat(frames,ignore_index=True)
comparecols=list(consolidated.columns)
assert Counter(map(tuple,rebuilt[comparecols].fillna('').values))==Counter(map(tuple,consolidated.fillna('').values)), 'Consolidation mismatch'
csv(rebuilt,'amrfinder_reconstruido_individuais.csv')
eligible_ids=set(quality.loc[quality.eligible,'genome_id']);data=rebuilt[rebuilt.genome_id.isin(eligible_ids)].copy()
data=data.drop(columns='species').merge(meta[['genome_id','species']],on='genome_id',validate='many_to_one')
amr=data[data.Type.eq('AMR')].copy();stress=data[data.Type.eq('STRESS')].copy()
csv(amr,'hits_AMR.csv');csv(stress,'hits_STRESS.csv')
target=amr[amr['Element symbol'].isin(targetlist)].copy();csv(target,'hits_alvo.csv')
matrix=meta.merge(quality[['genome_id','eligible','run_status']],on='genome_id',validate='one_to_one')
for g in targetlist+['mecA1']:
    matrix[g]=matrix.genome_id.isin(amr.loc[amr['Element symbol'].eq(g),'genome_id']).astype(float)
    matrix.loc[~matrix.eligible,g]=np.nan
matrix['n_alvos']=matrix[targetlist].sum(axis=1,min_count=1)
for metric in ['n_AMR_hits','n_AMR_genes','n_AMR_classes']:matrix[metric]=np.nan
for gid,sub in amr.groupby('genome_id'):
    matrix.loc[matrix.genome_id.eq(gid),['n_AMR_hits','n_AMR_genes','n_AMR_classes']]=[len(sub),sub['Element symbol'].nunique(),sub.Class.nunique()]
for metric in ['n_AMR_hits','n_AMR_genes','n_AMR_classes']:matrix.loc[matrix.eligible,metric]=matrix.loc[matrix.eligible,metric].fillna(0)
matrix['perfil']=matrix[targetlist].apply(lambda s:'+'.join(g for g in targetlist if s[g]==1) or 'nenhum',axis=1)
matrix.loc[~matrix.eligible,'perfil']='nao_avaliado'
csv(matrix,'genomas_metadados_resultados.csv')
csv(pd.DataFrame(contexts),'contexto_genetico_alvos.csv')
csv(pd.DataFrame(neighborhood),'vizinhanca_cfr_fexA_10kb.csv')
csv(pd.DataFrame([{'host_original':v,'host_grupo':hostmap(v),'n_genomas':n} for v,n in meta.host_original.value_counts(dropna=False).items()]),'dicionario_hospedeiros.csv')
csv(matrix.groupby(['species','host_grupo']).size().reset_index(name='n_genomas'),'composicao_especie_hospedeiro.csv','tabelas')
species=[]
for sp,sub in matrix.groupby('species'):
    ev=sub[sub.eligible]
    row=dict(species=sp,n_inventario=len(sub),n_analisados=len(ev),n_projetos=ev.bioproject.nunique(),alvo_positivo=int(ev.n_alvos.gt(0).sum()),qualquer_AMR=int(ev.n_AMR_genes.gt(0).sum()),mediana_genes_AMR=float(ev.n_AMR_genes.median()))
    for g in ['mecA','mecA1','fexA','cfr']:row[g]=int(ev[g].sum())
    species.append(row)
csv(pd.DataFrame(species),'Tabela1_especies.csv','tabelas')
hosts=[]
for host,sub in matrix.groupby('host_grupo'):
    ev=sub[sub.eligible]
    row=dict(host_grupo=host,n_inventario=len(sub),n_analisados=len(ev),n_especies=ev.species.nunique(),alvo_positivo=int(ev.n_alvos.gt(0).sum()),qualquer_AMR=int(ev.n_AMR_genes.gt(0).sum()),mediana_genes_AMR=float(ev.n_AMR_genes.median()))
    for g in ['mecA','mecA1','fexA','cfr']:row[g]=int(ev[g].sum())
    hosts.append(row)
csv(pd.DataFrame(hosts),'Tabela2_hospedeiros.csv','tabelas')
profiles=matrix[matrix.eligible].groupby('perfil').size().reset_index(name='n_genomas');csv(profiles,'Tabela3_perfis.csv','tabelas')
presence=amr[['genome_id','Element symbol']].drop_duplicates()
top=presence.groupby('Element symbol').size().sort_values(ascending=False).reset_index(name='n_genomas');csv(top,'TabelaS_genes_AMR.csv','tabelas')
evalmatrix=matrix[matrix.eligible];pets=evalmatrix[evalmatrix.host_grupo.isin(['cao','gato'])]
summary=dict(n_inventory=len(matrix),n_eligible=len(evalmatrix),excluded_ids=list(matrix.loc[~matrix.eligible,'genome_id']),n_species=evalmatrix.species.nunique(),n_AMR_hits=len(amr),n_STRESS_hits=len(stress),n_AMR_symbols=amr['Element symbol'].nunique(),n_AMR_classes=amr.Class.nunique(),n_genomes_any_AMR=int(evalmatrix.n_AMR_genes.gt(0).sum()),n_target_hits=len(target),n_target_positive=int(evalmatrix.n_alvos.gt(0).sum()),targets={g:int(evalmatrix[g].sum()) for g in targetlist+['mecA1']},host_inventory=matrix.host_grupo.value_counts().to_dict(),host_eligible=evalmatrix.host_grupo.value_counts().to_dict(),n_pets=len(pets),pets_species=pets.species.value_counts().to_dict(),n_pets_any_AMR=int(pets.n_AMR_genes.gt(0).sum()),pets_targets={g:int(pets[g].sum()) for g in targetlist},sequence_duplicate_groups=[v for v in assemblies.values() if len(v)>1],individual_results_equal_consolidation=True,n_bioprojects=evalmatrix.bioproject.nunique(),top_bioprojects=evalmatrix.bioproject.value_counts().head(10).to_dict(),context_n=len(contexts),software_reexecuted=False)
(OUT/'validacao/resumo_validacao.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
