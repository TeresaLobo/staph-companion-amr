from pathlib import Path
import pandas as pd
p=Path(__file__).resolve().parents[1];m=pd.read_csv(p/'dados/genomas_metadados_resultados.csv');e=m[m.eligible]
rows=[]
policies={'principal_integridade':e,'contaminacao_reportada_ate5_completude95':e[e.completeness.ge(95)&e.contamination.le(5)],'completude95_contaminacao_ate5_ou_ausente':e[e.completeness.ge(95)&(e.contamination.le(5)|e.contamination.isna())]}
for name,x in policies.items():
    rows.append(dict(criterio=name,n_genomas=len(x),n_positivos=int(x.n_alvos.gt(0).sum()),percentual=round(x.n_alvos.gt(0).mean()*100,3),mecA=int(x.mecA.sum()),mecA1=int(x.mecA1.sum()),fexA=int(x.fexA.sum()),cfr=int(x.cfr.sum()),n_caes=int(x.host_grupo.eq('cao').sum()),n_gatos=int(x.host_grupo.eq('gato').sum())))
pd.DataFrame(rows).to_csv(p/'tabelas/TabelaS_sensibilidade_qualidade.csv',index=False)
c=pd.read_csv(p/'dados/contexto_genetico_alvos.csv');c=c.rename(columns={'n_mobility_annotations_window':'n_recombination_or_transposition_annotations','mobility_annotations':'recombination_or_transposition_annotations'});c.to_csv(p/'dados/contexto_genetico_alvos.csv',index=False)
ct=c[c.gene.isin(['cfr','fexA'])].merge(m[['genome_id','host_grupo','host_original']],on='genome_id',validate='many_to_one')
ct.to_csv(p/'tabelas/Tabela3_contexto_cfr_fexA.csv',index=False)
print(pd.DataFrame(rows).to_string(index=False))
