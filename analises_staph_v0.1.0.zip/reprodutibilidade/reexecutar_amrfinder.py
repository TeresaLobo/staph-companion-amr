#!/usr/bin/env python3
"""Reanotate the damaged genome and rerun archived and combined AMRFinder searches.
No original file is modified. Run in an activated Linux bioinformatics environment.
Usage: python reexecutar_amrfinder.py PROJECT OUTPUT --database DATABASE_DIR
"""
from pathlib import Path
import argparse, csv, subprocess, json, hashlib, shutil
parser=argparse.ArgumentParser()
parser.add_argument('project',type=Path);parser.add_argument('output',type=Path)
parser.add_argument('--database',required=True,type=Path)
parser.add_argument('--threads',type=int,default=2)
parser.add_argument('--only-repair',action='store_true')
args=parser.parse_args()
project=args.project.resolve();output=args.output.resolve();database=args.database.resolve()
if output==project or project in output.parents:raise SystemExit('Choose output outside original project.')
if not database.is_dir():raise SystemExit('Database directory not found.')
for tool in ['prokka','amrfinder']:
    if not shutil.which(tool):raise SystemExit('Missing executable in active environment: '+tool)
version=subprocess.check_output(['amrfinder','--version'],text=True).strip()
if version!='4.2.7':raise SystemExit('Historical reproduction requires AMRFinderPlus 4.2.7; found '+version)
if database.name!='2026-03-24.1':raise SystemExit('Use the archived database 2026-03-24.1 for the first reproduction.')
output.mkdir(parents=True,exist_ok=True)
master=list(csv.DictReader((project/'metadata/genome_master_table.tsv').open(),delimiter='\t'))
broken='GCF_015272835.1_ASM1527283v1'
status=[]
for row in master:
    gid=row['genome_id']
    if args.only_repair and gid!=broken:continue
    fasta=project/row['genome_file'].split('/staph_optra_mobilome/')[1]
    original=project/'results/prokka'/gid
    if gid==broken:
        ann=output/'prokka_reanotado'/gid
        if ann.exists():raise SystemExit('Repair output already exists; choose a new output directory.')
        with (output/(gid+'.prokka.log')).open('w') as log:
            subprocess.run(['prokka',str(fasta),'--outdir',str(ann),'--prefix',gid,'--genus','Staphylococcus','--kingdom','Bacteria','--cpus',str(args.threads)],stdout=log,stderr=subprocess.STDOUT,check=True)
    else:ann=original
    protein=ann/(gid+'.faa');gff=ann/(gid+'.gff')
    for path in [fasta,protein,gff]:
        if not path.is_file():raise SystemExit('Missing input: '+str(path))
        if b'\x00' in path.read_bytes():raise SystemExit('NUL in input: '+str(path))
    for mode in ['protein_only','protein_nucleotide_gff']:
        dest=output/mode;dest.mkdir(exist_ok=True)
        result=dest/(gid+'.tsv');logpath=dest/(gid+'.log')
        if result.exists():raise SystemExit('Existing result would be overwritten: '+str(result))
        command=['amrfinder','-p',str(protein),'--database',str(database),'--threads',str(args.threads),'-o',str(result)]
        if mode=='protein_nucleotide_gff':command+=['-n',str(fasta),'-g',str(gff),'--annotation_format','prokka']
        with logpath.open('w') as log:run=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
        status.append(dict(genome_id=gid,species=row['species'],mode=mode,returncode=run.returncode,command=command,result=str(result),log=str(logpath)))
        (output/'execution_manifest.json').write_text(json.dumps({'version':version,'database':str(database),'runs':status},indent=2))
        if run.returncode:raise SystemExit('Search failed; inspect '+str(logpath))
    print('Completed '+gid,flush=True)
print('Searches finished. Reprocess outputs and compare before replacing manuscript numbers.')
