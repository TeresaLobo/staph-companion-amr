# Pacote do artigo — revisão e preparação da submissão

Autora: Teresa de Lisieux Guedes Ferreira Lôbo. Atualizado em 07/10/2026.

O manuscrito integral em português está em artigo_corrigido/manuscrito (PDF, RTF editável no Word e Markdown). Tabelas, figuras científicas, dados por genoma, validações e scripts estão nas respectivas pastas. sequencias_e_anotacoes_originais.zip reúne sequências e anotações originais dos 415 genomas. auditoria_inicial.zip preserva a análise inicial.

As coleções de Prokka e AMRFinderPlus no Galaxy aparecem concluídas. Os 415 relatórios AMRFinderPlus foram baixados, conferidos por CRC, identificadores de genoma, cabeçalhos e versões. Contêm 1.884 hits AMR e 78 STRESS. Alvos exatos por genoma: mecA 101, fexA 6, cfr 1; mecA1 separado em 25. Demais alvos (mecC, fexB, cfr(B/C/D), optrA, poxtA): zero. As tabelas tratadas, a comparação com os resultados antigos e os relatórios individuais novos estão em artigo_corrigido/reanotacao_sem_wsl/relatorios_tratados e amrfinder_415_Galaxy.zip.

ATENÇÃO À VERSÃO DO MANUSCRITO: texto, tabelas e figuras principais ainda apresentam as 414 buscas arquivadas validadas, com 1.842 hits AMR e 75 STRESS, base 2026-03-24.1 e busca proteica. Os relatórios novos usam base 2026-05-15.1 e busca combinada DNA/proteínas. Não misturar os denominadores nem descrever os números antigos como resultados novos.

O piloto recuperado tem validação completa: 2.240 CDSs/proteínas conferidos contra DNA, zero NUL, 52 contigs correspondentes e busca AMR concluída sem hits. Está em reanotacao_sem_wsl/piloto. A transferência das coleções maiores de FAA/GFF do Galaxy excedeu os tempos de download; sua validação local completa e a integração final ao manuscrito permanecem pendentes. O controle positivo concluiu com saída zero no Galaxy, mas seu relatório ainda precisa ser conferido localmente para confirmar os genes esperados.

Este pacote reúne todas as análises disponíveis localmente e o manuscrito para revisão. Ainda não é uma versão final pronta para submissão: concluir a integração/validação dos resultados novos; confirmar afiliação, e-mail, financiamento, conflitos, contribuição e declaração ética; revisão científica pela autora; depósito de dados/código com identificador persistente. A submissão ao periódico não foi realizada.

Periódico sugerido: Revista Brasileira de Ciência Veterinária (Medicina Veterinária Preventiva). Confirmar as normas vigentes na submissão: https://periodicos.uff.br/rbcv/about/submissions

Histórico Galaxy: https://usegalaxy.eu/histories/view?id=11ac94870d0bb33ab2ccba380d5f990b
