# Relatório de correções e limites

Autora: Teresa de Lisieux Guedes Ferreira Lôbo. Manuscrito em português.

## Trabalho concluído

- Inventário de 415 montagens; dados originais preservados no SSD.
- Reconstrução dos 414 resultados individuais de AMRFinderPlus: igualdade registro a registro com 1.917 hits arquivados, separados em 1.842 AMR e 75 STRESS.
- Correção de falsos agrupamentos de mecI e mecA1 como mecA. Alvos contados por símbolo exato: 105 genomas, mecA 101, fexA 6, cfr 1; mecA1 separado em 25.
- Conferência de FASTA, identificadores, coordenadas, comprimentos e correspondência FAA/GFF; tradução compatível de 133 CDSs dos alvos e mecA1.
- Correção da classificação dos hospedeiros; subconjunto explícito de cães/gatos: 82 genomas. Nenhuma detecção de cfr/fexA em cães/gatos nesta coleção.
- Atualização de Staphylococcus sciuri para Mammaliicoccus sciuri, preservando rótulos originais.
- Revisão do contexto: XerC/XerD são recombinases; sua proximidade não comprova transposon, plasmídeo ou transferência.
- Análise exploratória de sensibilidade às métricas de qualidade e discussão de seleção não aleatória, concentração por BioProject e dados ausentes.
- Manuscrito integralmente reescrito, tabelas recalculadas e figuras científicas vetoriais/rasterizadas.

## Situação anterior ao Galaxy — auditoria de 05/10/2026

GCF_015272835.1_ASM1527283v1 apresenta 265 bytes NUL no FAA e GFF truncado, com 28 proteínas sem CDS correspondente. Remover bytes NUL não recupera a anotação completa. Foi excluído dos denominadores da versão atual; falha não equivale a ausência de genes.

As validações locais não são uma nova execução de Prokka/AMRFinderPlus. Não se relata reanotação fictícia. O Windows disponível não tem ambiente Linux operacional, Docker ou Conda. A alternativa preparada é Galaxy Europe (https://usegalaxy.eu), com Prokka 1.14.6+galaxy2 e AMRFinderPlus 4.2.7+galaxy0 verificados no catálogo em 05/10/2026. O Prokka difere da versão registrada no ambiente original (1.15.6). Novas análises devem ser tratadas como conjunto harmonizado separado, registrando o banco efetivamente disponível; não como reprodução histórica idêntica.

Primeiro executar o genoma com falha como piloto; validar FAA/GFF/resultados e então aplicar a todos os 415 genomas. Após conclusão, comparar os novos hits por genoma/símbolo, revisar os denominadores, refazer contexto/figuras e atualizar o manuscrito. Nenhum resultado de reanotação remota foi incorporado até aqui.

## Antes da submissão

### Atualização da reanotação — 06/10/2026

O piloto GCF_015272835.1_ASM1527283v1 foi efetivamente reanotado no Galaxy Europe com Prokka 1.14.6+galaxy2, saída sem NUL, GFF completo e 2.240 proteínas/2.240 CDSs. Todos os CDSs foram traduzidos e conferidos contra o DNA original. O AMRFinderPlus 4.2.7+galaxy0 concluiu com código de saída zero e nenhum hit, usando a base 2026-05-15.1 e entrada combinada FAA/GFF/FSA. Os 52 contigs do FSA correspondem exatamente aos originais, sem contigs excluídos. Esses resultados estão em reanotacao_sem_wsl/piloto; os resultados antigos corrompidos foram preservados.

Os 415 genomas originais foram conferidos por SHA256, enviados e extraídos em coleção no Galaxy. Seus formatos foram corrigidos para FASTA. A reanotação completa e a busca combinada AMRFinderPlus (DNA original + FAA/GFF novos; formato Prokka; limiar curado de identidade, cobertura mínima 0,5; sem organismo/plus) foram submetidas. As páginas de submissão apresentaram HTTP 504, mas coleções foram criadas e trabalhos Prokka continuam concluindo no histórico. Não repetir a submissão sem conferir o estado. Um controle positivo independente com cfr/mecA, GCF_000712995.1_StaCap1.0, também foi submetido e aguarda execução.

O lote não está validado nem incorporado ao manuscrito nesta atualização. O denominador editorial permanece 414. A mudança de base e de modo de busca exige comparação formal; os valores antigos não foram apresentados como resultados novos.

Confirmar afiliação e e-mail da autora; financiamento, conflitos, contribuições e declaração ética institucional; concluir reanotação; revisar autoria científica; depositar dados e código com identificador persistente. O estudo não demonstra transmissão, prevalência populacional, resistência fenotípica ou reservatório específico de cfr em animais de companhia.
